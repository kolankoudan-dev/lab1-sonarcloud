Гребенюк Євгеній Андрійович Бст-125-23-3-СЗ
створив акаунт гітхаб
<img width="1885" height="874" alt="image" src="https://github.com/user-attachments/assets/7c17ca61-9046-4590-bc25-f770274e324b" />

створив акаунт на сонарклауд
<img width="1909" height="926" alt="image" src="https://github.com/user-attachments/assets/71bf7389-5e39-4f4f-b9ad-ac09f2cf1125" />

склонував проект викладача
<img width="621" height="238" alt="image" src="https://github.com/user-attachments/assets/b2f2f01d-877c-4d70-8ca6-fd9ee92e281d" />

додав його до сонарклауда
<img width="1913" height="891" alt="image" src="https://github.com/user-attachments/assets/76a9ef42-9d8f-4346-9311-363a8759cde7" />

Створюю в проекті .github/workflows/sonarcloud.yml з автоматичними тригерами на push та pull_request для гілки main. Workflow автоматично запускається при кожному коміті або створенні Pull Request.
<img width="1902" height="906" alt="image" src="https://github.com/user-attachments/assets/08077c6d-552c-419a-8b7e-97bc965d3dcc" />

Далі необхідно вимкнути Automatic Analysis в проєкті.
<img width="1902" height="911" alt="image" src="https://github.com/user-attachments/assets/494036fb-7364-4a7f-a563-748f8cfd2546" />

Під час перевірки PR-декорації у вкладці Checks було підтверджено коректність виконання всіх автоматизованих процедур: статус All checks have passed засвідчив успішне проходження всіх перевірок, а повідомлення No conflicts with base branch означало відсутність конфліктів із базовою гілкою. Quality Gate отримав позначку Passed, що свідчить про відповідність коду встановленим критеріям якості. Усі GitHub Actions були виконані без помилок, а аналіз SonarCloud не виявив нових проблем чи зауважень.

